Filelist:
ATmega328PB_Xplained_Mini_layer_plots_release_rev3.pdf : PCB Layer Plots
BOM\Bill of Materials Print- ATmega328PB_Xplained_Mini_release_rev3.xls : BOM, fitted components
ExportSTEP\ATmega328PB_Xplained_Mini_release_rev3.step : 3D Model of PCBA
NC Drill\ATmega328PB_Xplained_Mini_release_rev3.drl : Drill files, gerber
NC Drill\ATmega328PB_Xplained_Mini_release_rev3.drr : Drill Files Report
ODB\ATmega328PB_Xplained_Mini_release_rev3.zip : ODB++ Files
Pick Place\Pick Place for ATmega328PB_Xplained_Mini_release_rev3.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for ATmega328PB_Xplained_Mini_release_rev3.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for ATmega328PB_Xplained_Mini_release_rev3.csv : Assembly Testpoint report, csv
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GP1 : Gerber files for Power Plane
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GM1 : Gerber files for Mechanical 1
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GBO : Gerber files for Bottom Overlay
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GBL : Gerber files for Bottom Layer
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GBS : Gerber files for Bottom Solder
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GTL : Gerber files for Top Layer
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GTO : Gerber files for Top Overlay
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GTP : Gerber files for Top Paste
Gerber\ATmega328PB_Xplained_Mini_release_rev3.GTS : Gerber files for Top Solder
ATmega328PB_Xplained_Mini_design_documentation_release_rev3.PDF : Design Documentation with Bom
NC Drill\ATmega328PB_Xplained_Mini_release_rev3.LDP : Layer Pairs Definition
NC Drill\ATmega328PB_Xplained_Mini_-RoundHoles_release_rev3.txt : Drill files, ASCII-RoundHoles
NC Drill\ATmega328PB_Xplained_Mini_-SlotHoles_release_rev3.txt : Drill files, ASCII-SlotHoles
Gerber\ATmega328PB_Xplained_Mini_release_rev3.G1 : Gerber files for MID Layer 1
